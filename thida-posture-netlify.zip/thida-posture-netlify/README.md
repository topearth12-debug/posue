# THIDA 姿勢歪みチェック

正面カメラで骨格を検出し、施術前後の歪みスコアを比較するアプリです。

## ローカルで動作確認する場合

```bash
npm install
npm run dev
```

ブラウザで `http://localhost:5173` を開いてください。
カメラを使うため、スマホの実機で試す場合は同一Wi-Fi内でPCのIPアドレス経由（例: `http://192.168.x.x:5173`）でアクセスするか、下記のNetlifyデプロイ後にHTTPSのURLで開いてください。
（ブラウザのカメラAPIはHTTPS、または`localhost`でしか動作しません。）

## Netlifyへのデプロイ方法

### 方法A: Netlifyのサイトにドラッグ&ドロップ（一番簡単）

1. このフォルダをローカルに展開し、ターミナルで以下を実行してビルドします。
   ```bash
   npm install
   npm run build
   ```
2. `dist` フォルダが生成されます。
3. https://app.netlify.com/drop を開き、生成された `dist` フォルダをそのままドラッグ&ドロップします。
4. 発行されたURL（例: `https://xxxx.netlify.app`）をスマホで開けば完了です。

### 方法B: GitHub連携で自動デプロイ

1. このフォルダをGitHubリポジトリにpushします。
2. Netlifyで「Add new site」→「Import an existing project」からそのリポジトリを選択します。
3. ビルド設定は `netlify.toml` に書いてあるので自動で認識されます（Build command: `npm run build`、Publish directory: `dist`）。
4. デプロイ完了後、発行されたURLをスマホで開きます。

## データの保存について

お客様情報・履歴は、ブラウザの `localStorage` に保存されます（`storageAdapter` が自動でこの方式を使います）。
- 同じスマホ・同じブラウザでアクセスする限りデータは保持されます。
- ブラウザのキャッシュ・データを消去すると記録も消えるため、必要に応じてバックアップ手段（スプレッドシート転記など）の検討をおすすめします。
- 複数端末でデータを共有したい場合は、将来的にFirebaseやSupabaseなどのクラウドDBに置き換える拡張が可能です。

## カメラについて

- 撮影は正面から1枚のみです。全身が入るよう2〜3m離れて立って撮影してください。
- 骨格検出には TensorFlow.js（MoveNet モデル）を使用しており、初回アクセス時にモデルファイルをダウンロードします（数MB程度、数秒かかります）。Wi-Fi環境での利用を推奨します。
